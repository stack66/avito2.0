import { PluginsType } from "../types";
export declare const PanzoomPlugins: PluginsType;
