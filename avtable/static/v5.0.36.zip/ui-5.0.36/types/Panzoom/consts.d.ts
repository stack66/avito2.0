export declare enum States {
    Init = 0,
    Error = 1,
    Ready = 2,
    Panning = 3,
    Mousemove = 4,
    Destroy = 5
}
export declare const MatrixKeys: readonly ["a", "b", "c", "d", "e", "f"];
