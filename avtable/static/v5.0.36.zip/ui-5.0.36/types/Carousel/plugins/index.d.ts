import { PluginsType } from "../types";
export type * from "./Dots/Dots";
export type * from "./Navigation/Navigation";
export type * from "./Sync/Sync";
export declare const CarouselPlugins: PluginsType;
