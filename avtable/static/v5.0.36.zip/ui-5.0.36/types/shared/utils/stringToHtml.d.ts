export declare const stringToHtml: (str: string) => HTMLElement;
