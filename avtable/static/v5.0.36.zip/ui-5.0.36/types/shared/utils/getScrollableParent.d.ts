export declare const isScrollable: (ele: HTMLElement | null) => boolean;
export declare const getScrollableParent: (ele: HTMLElement, limit?: HTMLElement | undefined) => false | HTMLElement;
