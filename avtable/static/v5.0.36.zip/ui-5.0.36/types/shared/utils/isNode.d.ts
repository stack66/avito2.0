export declare const isNode: (variable: any) => boolean;
