export declare const splitClasses: (classes?: string) => string[];
