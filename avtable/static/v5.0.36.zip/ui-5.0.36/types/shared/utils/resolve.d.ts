export declare const resolve: <T>(path: string, obj: T) => any;
