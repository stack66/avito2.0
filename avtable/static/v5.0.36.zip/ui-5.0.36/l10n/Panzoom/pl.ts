export const pl = {
  PANUP: "Przesuń w górę",
  PANDOWN: "Przesuń w dół",
  PANLEFT: "Przesuń w lewo",
  PANRIGHT: "Przesuń w prawo",

  ZOOMIN: "Zbliż",
  ZOOMOUT: "Oddal",

  TOGGLEZOOM: "Zbliż/oddal",
  TOGGLE1TO1: "Zmieść/skala 1:1",
  ITERATEZOOM: "Zbliż/oddal",

  ROTATECCW: "Obróć w lewo",
  ROTATECW: "Obróć w prawo",

  FLIPX: "Obróć w poziomie",
  FLIPY: "Obróć w pionie",

  FITX: "Dopasuj do szerokości ekranu",
  FITY: "Dopasuj do wysokości ekranu",

  RESET: "Resetuj",

  TOGGLEFS: "Włącz/wyłącz tryb pełnego ekranu",
};
