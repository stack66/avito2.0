export const it = {
  PANUP: "Sposta su",
  PANDOWN: "Sposta giù",
  PANLEFT: "Sposta a sinistra",
  PANRIGHT: "Sposta a destra",

  ZOOMIN: "Ingrandisci",
  ZOOMOUT: "Rimpicciolisci",

  TOGGLEZOOM: "Alterna il livello di zoom",
  TOGGLE1TO1: "Alterna il livello di zoom",
  ITERATEZOOM: "Attiva/disattiva livello di zoom",

  ROTATECCW: "Ruota in senso antiorario",
  ROTATECW: "Ruota in senso orario",

  FLIPX: "Capovolgi orizzontalmente",
  FLIPY: "Capovolgi verticalmente",

  FITX: "Adatta orizzontalmente",
  FITY: "Adatta verticalmente",

  RESET: "Reimposta",

  TOGGLEFS: "Attiva/disattiva schermo intero",
};
