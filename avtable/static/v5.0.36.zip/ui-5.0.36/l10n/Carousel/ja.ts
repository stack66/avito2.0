export const ja = {
  NEXT: "次のスライド",
  PREV: "前のスライド",
  GOTO: "スライド #%d に移動",
};
