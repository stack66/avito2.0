export const zh_CN = {
  NEXT: "下一张",
  PREV: "上一张",
  GOTO: "转至幻灯片 #%d",
};
