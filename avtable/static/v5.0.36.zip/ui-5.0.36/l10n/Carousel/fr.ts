export const fr = {
  NEXT: "Diapositive suivante",
  PREV: "Diapositive précédente",
  GOTO: "Aller à la diapositive #%d",
};
